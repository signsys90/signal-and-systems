// View the kit STL files in OpenSCAD (free, https://openscad.org)
// Open this file from inside the STL folder, then press F5 to view.
// Keep this file in the same folder as the STL files.
//
// Mouse: left-drag = rotate, right-drag = pan, scroll = zoom.
// View > Reset View if the model is off screen.

show = "shroud";   // "shroud", "gauge", or "both"

if (show == "shroud" || show == "both")
    color("DimGray") import("sds200_glare_shroud_v1.0.stl");

if (show == "gauge")
    color("SlateGray") import("sds200_fit_gauge_v1.0.stl");

if (show == "both")
    translate([0, -90, 0]) color("SlateGray") import("sds200_fit_gauge_v1.0.stl");
