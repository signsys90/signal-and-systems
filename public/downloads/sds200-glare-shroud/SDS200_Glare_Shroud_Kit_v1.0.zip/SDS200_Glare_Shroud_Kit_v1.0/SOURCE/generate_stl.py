#!/usr/bin/env python3
"""
Uniden SDS200 Display Glare Shroud - STL generator (v1.0)

Python mirror of sds200_glare_shroud.scad, for users without OpenSCAD.
The parameters below MUST match the .scad file defaults if you edit one.

Requires: pip install trimesh manifold3d numpy
Usage:    python generate_stl.py            (writes both STLs to ./out)
          python generate_stl.py --win-w 78 --win-h 60 --flange 5
"""
import argparse, math, os
import numpy as np
import trimesh


def box(x, y, z, dx, dy, dz):
    return trimesh.creation.box(
        [dx, dy, dz],
        trimesh.transformations.translation_matrix([x + dx / 2, y + dy / 2, z + dz / 2]))


def corners(x, y, z, dx, dy, dz):
    return [[x + a, y + b, z + c] for a in (0, dx) for b in (0, dy) for c in (0, dz)]


def hull(points):
    return trimesh.convex.convex_hull(np.array(points))


def build(p):
    win_w, win_h, fl, ft, wt = p.win_w, p.win_h, p.flange, p.flange_t, p.wall_t
    hf, hn = p.h_far, p.h_near
    of = hf * math.tan(math.radians(p.flare))
    on = hn * math.tan(math.radians(p.flare))
    yf, yn, e = win_h / 2, -win_h / 2, 0.4  # e = hull construction thickness

    plate = box(-(win_w / 2 + fl), -(win_h / 2 + fl), 0, win_w + 2 * fl, win_h + 2 * fl, ft) \
        .difference(box(-win_w / 2, -win_h / 2, -1, win_w, win_h, ft + 2))

    zb = ft / 2  # walls start inside the flange (overlap, not face-to-face contact)
    parts = [plate]
    for s in (1, -1):
        x0 = s * win_w / 2
        o = 0 if s > 0 else -wt
        parts.append(hull(corners(x0 + o + s * zb * math.tan(math.radians(p.flare)), yn, zb, wt, win_h + wt, e)
                          + corners(x0 + s * of + o, yf, hf, wt, wt, e)
                          + corners(x0 + s * on + o, yn, hn, wt, e, e)))
    parts.append(hull(corners(-win_w / 2 - wt / 2, yf, zb, win_w + wt, wt, e)
                      + corners(-win_w / 2 - wt / 2 - of, yf, hf, win_w + wt + 2 * of, wt, e)))
    if p.near_lip > 0:
        parts.append(box(-win_w / 2 - wt / 2, yn - wt, zb, win_w + wt, wt, p.near_lip))

    return trimesh.boolean.union(parts), plate


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--win-w", type=float, default=76)
    ap.add_argument("--win-h", type=float, default=58)
    ap.add_argument("--flange", type=float, default=6)
    ap.add_argument("--flange-t", type=float, default=2.0)
    ap.add_argument("--wall-t", type=float, default=2.4)
    ap.add_argument("--h-far", type=float, default=45)
    ap.add_argument("--h-near", type=float, default=10)
    ap.add_argument("--flare", type=float, default=12)
    ap.add_argument("--near-lip", type=float, default=0)
    ap.add_argument("--out", default="out")
    p = ap.parse_args()

    os.makedirs(p.out, exist_ok=True)
    shroud, gauge = build(p)
    shroud.export(os.path.join(p.out, "sds200_glare_shroud.stl"))
    gauge.export(os.path.join(p.out, "sds200_fit_gauge.stl"))
    for name, m in (("shroud", shroud), ("gauge", gauge)):
        print(f"{name}: watertight={m.is_watertight} "
              f"size={np.round(m.extents, 1).tolist()} mm volume={m.volume / 1000:.1f} cm3")


if __name__ == "__main__":
    main()
