// ============================================================================
//  Uniden SDS200 Display Glare Shroud  -  Parametric Source  -  v1.0
// ============================================================================
//  Purpose : Wedge-style visor that shades the SDS200 display when the radio is
//            mounted face-up (vertically) in a vehicle center console.
//  Tool    : OpenSCAD 2021.01 or newer (free, https://openscad.org)
//  Units   : millimetres
//
//  HOW TO USE
//    1. Measure the radio (see README / PDF, Section 3) and edit the
//       "MEASURE ON THE RADIO" values below.
//    2. Set part = "gauge" and render (F6) / export STL to print a 2 mm
//       fit-test frame. Confirm fit on the radio.
//    3. Set part = "shroud", render (F6), File > Export > Export as STL.
//
//  MODEL ORIENTATION
//    X = across the display, Y = along the display, Z = out of the radio face.
//    +Y edge = FAR side (away from the viewer)  -> tallest wall.
//    -Y edge = NEAR side (toward the viewer)    -> open (or optional low lip).
//    Print flange-down exactly as modelled. No supports required.
// ============================================================================

// ---------- PART SELECT ----------
part = "shroud";   // "shroud" = production part, "gauge" = fit-test frame only

// ---------- MEASURE ON THE RADIO (calipers) ----------
win_w   = 76;      // opening width  = visible display width  + ~2 mm   [ESTIMATE]
win_h   = 58;      // opening height = visible display height + ~2 mm   [ESTIMATE]
flange  = 6;       // flat bezel land around display usable for tape     [ESTIMATE]

// ---------- SHAPE ----------
flange_t = 2.0;    // flange thickness
wall_t   = 2.4;    // wall thickness (6 perimeters @ 0.4 mm nozzle)
h_far    = 45;     // far wall height (blocks overhead / roof-glass light)
h_near   = 10;     // side-wall height at the near (viewer) end
flare    = 12;     // degrees each side wall leans outward
near_lip = 0;      // 0 = fully open near side; e.g. 4 = small stiffening lip

// ---------- DERIVED (do not edit) ----------
off_far  = h_far  * tan(flare);
off_near = h_near * tan(flare);
y_far    =  win_h/2;
y_near   = -win_h/2;
e        = 0.4;      // construction thickness for hull edges
zb       = flange_t/2; // walls start inside the flange (overlap, avoids coplanar faces)

module flange_plate() {
    difference() {
        translate([-(win_w/2+flange), -(win_h/2+flange), 0])
            cube([win_w+2*flange, win_h+2*flange, flange_t]);
        translate([-win_w/2, -win_h/2, -1])
            cube([win_w, win_h, flange_t+2]);
    }
}

// Side wall: wedge from far end to near end, leaning outward by "flare".
module side_wall(s) {              // s = +1 right, -1 left
    x0 = s*win_w/2;
    o  = (s > 0) ? 0 : -wall_t;
    hull() {
        translate([x0 + s*zb*tan(flare) + o, y_near, zb]) cube([wall_t, win_h+wall_t, e]);
        translate([x0 + s*off_far  + o, y_far,  h_far ]) cube([wall_t, wall_t,       e]);
        translate([x0 + s*off_near + o, y_near, h_near]) cube([wall_t, e,            e]);
    }
}

module far_wall() {
    hull() {
        // ends mid-thickness inside the side walls so the solids overlap
        translate([-win_w/2 - wall_t/2,           y_far, zb   ]) cube([win_w+wall_t,           wall_t, e]);
        translate([-win_w/2 - wall_t/2 - off_far, y_far, h_far]) cube([win_w+wall_t+2*off_far, wall_t, e]);
    }
}

module near_lip_wall() {
    if (near_lip > 0)
        translate([-win_w/2 - wall_t/2, y_near - wall_t, zb])
            cube([win_w+wall_t, wall_t, near_lip]);
}

module shroud() {
    union() {
        flange_plate();
        side_wall(+1);
        side_wall(-1);
        far_wall();
        near_lip_wall();
    }
}

if (part == "gauge") flange_plate();
else                 shroud();
