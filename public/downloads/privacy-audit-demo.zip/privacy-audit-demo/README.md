PRIVACY & TRACKING AUDIT: DEMONSTRATION REBUILD
Signal & Systems Engineering, LLC. | Built October 27, 2026

What this is
A working, cleaned-up demonstration of the kind of auditing William A. Atkins's original SaniGLAZE application performed. It was rebuilt from scratch on October 27, 2026 because no screenshots, reports, or code from the original survive. It is NOT the original application, and it contains no SaniGLAZE data.

What it does
• Serves three fictional "Example Coatings Co." test properties locally (main site, locations directory, promotion landing page), each with a consent banner. Two are deliberately misconfigured.
• Drives a real Chromium browser (Playwright) through every property in three consent states: A (no interaction), B (after "Reject all"), C (after "Accept all"), each in a fresh browser profile.
• Records third-party requests, cookies, and local storage keys; matches them against vendor signatures (signatures.json); applies review rules; writes out/results.json.
• Builds a self-contained interactive dashboard (out/dashboard.html) with findings, a consent behavior matrix, vendor and cookie inventories, and coverage limits. The "Apply fix" button is disabled: in the original, changes required an authorized user with the proper access and API credentials.

Safety
• Every request is intercepted and served locally. Google and LinkedIn scripts are replaced by small stubs; no request reaches any real vendor.
• Identifiers are placeholders (G-DEMO000001, AW-DEMO999999, partner 000000). Domains use the reserved .test TLD.

Run it
node scan.js && node build-dashboard.js && node shots.js
(Requires Node and Playwright with Chromium.)

Files
config.json (targets and approved accounts) · signatures.json (vendor rules) · scan.js (scanner and rules) · build-dashboard.js · shots.js · sites/ (fictional test sites) · stubs/ (stand-in vendor scripts) · out/ (results, dashboard, screenshots)
