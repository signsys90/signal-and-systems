(function(){try{localStorage.setItem('wc_visitor_id','demo-0000-0000');}catch(e){}new Image().src='https://collect.widgetcorp.test/v1/hit?demo=1';})();
