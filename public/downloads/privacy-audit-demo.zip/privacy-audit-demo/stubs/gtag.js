(function(){var id=(document.currentScript&&document.currentScript.src.match(/id=([^&]+)/)||[])[1]||'unknown';var exp='; path=/; max-age=63072000';
if(id.indexOf('G-')===0){document.cookie='_ga=GA1.1.000000000.0000000000'+exp;document.cookie='_ga_'+id.slice(2)+'=GS1.1.demo'+exp;new Image().src='https://region1.google-analytics.com/g/collect?v=2&tid='+id+'&en=page_view';}
if(id.indexOf('AW-')===0){document.cookie='_gcl_au=1.1.000000000.0000000000'+exp;new Image().src='https://googleads.g.doubleclick.net/pagead/viewthroughconversion/'+id.slice(3)+'/?demo=1';}})();
