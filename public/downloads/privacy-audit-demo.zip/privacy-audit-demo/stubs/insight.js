(function(){new Image().src='https://px.ads.linkedin.com/collect?pid=000000&fmt=gif&demo=1';})();
