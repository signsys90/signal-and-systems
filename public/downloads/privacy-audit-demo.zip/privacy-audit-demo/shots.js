const fs = require('fs'); const path = require('path'); const { chromium } = require('playwright');
(async () => {
  const out = path.join(__dirname, 'out'); const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1280, height: 860 }, deviceScaleFactor: 1.5 });
  await p.goto('file://' + path.join(out, 'dashboard.html'));
  await p.click('tr.f[data-id="F02"]');
  await p.screenshot({ path: path.join(out, 'demo-dashboard-findings.png'), fullPage: true });
  for (const t of ['matrix', 'vendors', 'cookies', 'coverage']) {
    await p.click('#tabs button[data-t="' + t + '"]');
    await p.screenshot({ path: path.join(out, 'demo-dashboard-' + t + '.png'), fullPage: true });
  }
  const shots = JSON.parse(fs.readFileSync(path.join(out, 'site-shots.json')));
  fs.writeFileSync(path.join(out, 'demo-test-site-banner.png'), Buffer.from(shots.locations, 'base64'));
  await b.close();
})();
