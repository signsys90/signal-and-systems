// Fictional consent banner for the demo test sites.
(function () {
  var m = document.cookie.match(/(?:^|; )demo_consent=([^;]+)/);
  window.demoConsent = m ? m[1] : null;
  if (window.demoConsent) return;
  document.addEventListener('DOMContentLoaded', function () {
    var b = document.createElement('div');
    b.id = 'consent-banner';
    b.innerHTML = '<p><strong>We use cookies.</strong> We use analytics and advertising cookies to improve this fictional demo site. Choose whether to allow them.</p>' +
      '<div><button id="reject">Reject all</button><button id="accept">Accept all</button></div>';
    document.body.appendChild(b);
    function set(v) { document.cookie = 'demo_consent=' + v + '; path=/; max-age=31536000'; location.reload(); }
    document.getElementById('accept').onclick = function () { set('accepted'); };
    document.getElementById('reject').onclick = function () { set('rejected'); };
  });
})();
function loadScript(src) { var s = document.createElement('script'); s.async = true; s.src = src; document.head.appendChild(s); }
function whenConsented(fn) { if (window.demoConsent === 'accepted') fn(); }
