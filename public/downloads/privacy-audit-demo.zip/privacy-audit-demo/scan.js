// Demonstration privacy and tracking scanner. Fictional test sites only.
// Drives a real Chromium browser, tests three consent states, records requests,
// cookies and storage, matches vendor signatures, and applies review rules.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const dir = __dirname;
const config = JSON.parse(fs.readFileSync(path.join(dir, 'config.json'), 'utf8'));
const signatures = JSON.parse(fs.readFileSync(path.join(dir, 'signatures.json'), 'utf8'));
const read = (p) => fs.readFileSync(path.join(dir, p), 'utf8');

// Everything is served locally. No request leaves this machine.
async function serve(route) {
  const url = new URL(route.request().url());
  const site = url.hostname.match(/^(www|locations|promo)\.example-coatings\.test$/);
  const js = (body) => route.fulfill({ status: 200, contentType: 'application/javascript', body });
  if (site) {
    const name = site[1] === 'www' ? 'main' : site[1];
    if (url.pathname === '/cmp.js') return js(read('sites/cmp.js'));
    if (url.pathname === '/style.css') return route.fulfill({ status: 200, contentType: 'text/css', body: read('sites/style.css') });
    return route.fulfill({ status: 200, contentType: 'text/html', body: read(`sites/${name}.html`) });
  }
  if (url.hostname === 'www.googletagmanager.com') return js(read('stubs/gtag.js'));
  if (url.hostname === 'snap.licdn.com') return js(read('stubs/insight.js'));
  if (url.hostname === 'cdn.widgetcorp.test') return js(read('stubs/widget.js'));
  return route.fulfill({ status: 204, body: '' });
}

const STATES = [
  { id: 'A', label: 'No interaction (before consent)', action: null },
  { id: 'B', label: 'After "Reject all"', action: '#reject' },
  { id: 'C', label: 'After "Accept all"', action: '#accept' },
];

function siteOf(host) { return host.split('.').slice(-2).join('.'); }

function match(kind, value) {
  for (const s of signatures) for (const p of s[kind] || []) if (new RegExp(p).test(value)) return s;
  return null;
}

function ids(url, sig) {
  const out = [];
  for (const p of (sig && sig.idPatterns) || []) { const m = url.match(new RegExp(p)); if (m) out.push((sig.idPrefix || '') + m[1]); }
  return out;
}

async function scanPage(browser, prop, pagePath, state) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await context.route('**/*', serve);
  const page = await context.newPage();
  const url = new URL(pagePath, prop.start).toString();
  let phase = 'load';
  const requests = [];
  page.on('request', (r) => requests.push({ url: r.url(), type: r.resourceType(), phase }));
  await page.goto(url, { waitUntil: 'load' });
  await page.waitForTimeout(config.observationWindowMs);
  const banner = (await page.$('#consent-banner')) !== null;
  let shot = null;
  if (state.action && banner) {
    requests.length = 0; // judge B and C only on what happens after the choice
    phase = 'after-choice';
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.click(state.action)]);
    await page.waitForTimeout(config.observationWindowMs);
  }
  if (state.id === 'A') shot = await page.screenshot();
  const cookies = await context.cookies();
  const storage = await page.evaluate(() => Object.keys(localStorage).map((k) => ({ key: k, bytes: (localStorage.getItem(k) || '').length })));
  await context.close();

  const pageHost = new URL(url).hostname;
  const thirdParty = requests.filter((r) => siteOf(new URL(r.url).hostname) !== siteOf(pageHost));
  const hits = [];
  for (const r of thirdParty) {
    const sig = match('scripts', r.url) || match('requests', r.url);
    hits.push({ url: r.url.split('?')[0], query: r.url.includes('?'), host: new URL(r.url).hostname, type: r.type,
      vendor: sig ? sig.vendor : null, product: sig ? sig.product : null, category: sig ? sig.category : 'unclassified', ids: ids(r.url, sig) });
  }
  const cookieRows = cookies.map((c) => {
    const sig = match('cookies', c.name);
    return { name: c.name, domain: c.domain, firstParty: siteOf(c.domain.replace(/^\./, '')) === siteOf(pageHost),
      expires: c.expires > 0 ? Math.round((c.expires - Date.now() / 1000) / 86400) + ' days' : 'session',
      secure: c.secure, sameSite: c.sameSite, vendor: sig ? sig.vendor : null, product: sig ? sig.product : null, category: sig ? sig.category : 'unclassified' };
  });
  return { property: prop.id, page: url, state: state.id, banner, requests: hits, cookies: cookieRows, storage, shot };
}

function rules(observations) {
  const findings = [];
  const add = (f) => findings.push({ id: 'F' + String(findings.length + 1).padStart(2, '0'), status: 'New', ...f });
  const trackerCats = ['analytics', 'advertising'];
  const byProp = {};
  for (const o of observations) (byProp[o.property] ||= {})[o.state] = o;
  const products = (o) => [...new Set(o.requests.filter((r) => trackerCats.includes(r.category)).map((r) => r.product))];

  for (const [prop, st] of Object.entries(byProp)) {
    const name = config.properties.find((p) => p.id === prop).name;
    if (!st.A.banner && products(st.A).length)
      add({ priority: 'High', property: name, rule: 'Trackers present with no consent banner', products: products(st.A), state: 'A',
        explanation: 'Analytics or advertising requests were observed on a property where no consent banner appeared.', owner: 'Web operations', fix: 'Add the consent banner to this property and gate tags behind it.' });
    for (const p of products(st.A))
      if (st.A.banner) add({ priority: 'High', property: name, rule: 'Tracker fired before any consent choice', products: [p], state: 'A',
        explanation: `${p} sent requests while the consent banner was still showing and no choice had been made.`, owner: 'Marketing technology',
        fix: 'Move the tag behind the consent trigger (for example, fire only on an "accepted" consent event).' });
    for (const p of products(st.B))
      add({ priority: 'High', property: name, rule: 'Tracker fired after "Reject all"', products: [p], state: 'B',
        explanation: `${p} sent requests after the visitor chose "Reject all".`, owner: 'Marketing technology',
        fix: 'Remove the hard-coded tag or route it through the consent manager so a rejection is honored.' });
    const unknown = [...new Set(Object.values(st).flatMap((o) => o.requests.filter((r) => r.category === "unclassified").map((r) => siteOf(r.host))))];
    for (const h of unknown)
      add({ priority: 'Medium', property: name, rule: 'Unclassified third-party domain', products: [h], state: 'A/B/C',
        explanation: `Requests went to ${h} (script and data endpoints), which does not match any known vendor signature.`, owner: 'Web operations',
        fix: 'Identify the owner and purpose of this script; remove it or add it to the vendor register and consent configuration.' });
    const storage = [...new Set(Object.values(st).flatMap((o) => o.storage.map((s) => s.key)))];
    for (const k of storage)
      add({ priority: 'Medium', property: name, rule: 'Identifier written to browser storage', products: [k], state: 'A/B/C',
        explanation: `Local storage key "${k}" was written, including in states where no consent was given.`, owner: 'Web operations',
        fix: 'Confirm what writes this key and whether it should depend on consent.' });
    const seen = [...new Set(Object.values(st).flatMap((o) => o.requests.flatMap((r) => r.ids)))];
    for (const id of seen.filter((i) => !config.approvedAccounts.includes(i)))
      add({ priority: 'Medium', property: name, rule: 'Tag account not on the approved list', products: [id], state: 'C',
        explanation: `A tag reports to account ${id}, which is not on the organization's approved account list. It may be a leftover or agency-owned tag.`, owner: 'Marketing technology',
        fix: 'Confirm who owns this account; remove the tag if it is no longer needed.' });
  }
  const accepted = Object.fromEntries(Object.entries(byProp).map(([k, v]) => [k, new Set(products(v.C))]));
  const all = [...new Set(Object.values(accepted).flatMap((s) => [...s]))];
  for (const p of all) {
    const missing = Object.keys(accepted).filter((k) => !accepted[k].has(p));
    if (missing.length && missing.length < Object.keys(accepted).length)
      add({ priority: 'Low', property: 'Cross-property', rule: 'Inconsistent tag deployment', products: [p], state: 'C',
        explanation: `${p} is present on some properties but not on: ${missing.map((m) => config.properties.find((x) => x.id === m).name).join(', ')}.`, owner: 'Marketing technology',
        fix: 'Decide whether the tag belongs on every property and align the deployment.' });
  }
  return findings;
}

(async () => {
  const started = new Date();
  const browser = await chromium.launch();
  const observations = [];
  const shots = {};
  for (const prop of config.properties)
    for (const pg of prop.pages)
      for (const st of STATES) {
        const o = await scanPage(browser, prop, pg, st);
        if (o.shot) shots[prop.id] = o.shot.toString('base64');
        delete o.shot;
        observations.push(o);
        console.log(`${prop.id} ${st.id}: ${o.requests.length} third-party requests, ${o.cookies.length} cookies, banner=${o.banner}`);
      }
  await browser.close();
  const findings = rules(observations);
  const result = { organization: config.organization, startedAt: started.toISOString(), finishedAt: new Date().toISOString(),
    properties: config.properties.map(({ id, name, start }) => ({ id, name, start })), states: STATES.map(({ id, label }) => ({ id, label })),
    approvedAccounts: config.approvedAccounts, observations, findings };
  fs.writeFileSync(path.join(dir, 'out', 'results.json'), JSON.stringify(result, null, 2));
  fs.writeFileSync(path.join(dir, 'out', 'site-shots.json'), JSON.stringify(shots));
  console.log(`${findings.length} findings`);
  for (const f of findings) console.log(`${f.id} ${f.priority} ${f.property}: ${f.rule} [${f.products.join(', ')}]`);
})();
